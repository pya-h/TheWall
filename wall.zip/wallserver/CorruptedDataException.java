package wallserver;

public class CorruptedDataException extends Exception {
    public CorruptedDataException(String message) {
        super(message);
    }
}
