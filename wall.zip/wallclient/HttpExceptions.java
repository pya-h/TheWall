package wallclient;

public class HttpExceptions extends Exception {

    public HttpExceptions(String message) {
        super(message);
    }
}
